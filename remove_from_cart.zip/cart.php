<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT cart.*, games.title, games.price FROM cart JOIN games ON cart.game_id = games.id WHERE cart.user_id = $user_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Your Cart</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="catalog.php">Catalog</a>
            <a href="cart.php">Cart</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                <a href="admin.php">Admin</a>
            <?php endif; ?>
        </nav>
    </header>
    <main>
        <?php if ($result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Game</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
                <?php
                $total_price = 0;
                while($row = $result->fetch_assoc()):
                    $total = $row['price'] * $row['quantity'];
                    $total_price += $total;
                ?>
                    <tr>
                        <td><?php echo $row['title']; ?></td>
                        <td>$<?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td>$<?php echo $total; ?></td>
                        <td><a href="remove_from_cart.php?id=<?php echo $row['id']; ?>">Remove</a></td>
                    </tr>
                <?php endwhile; ?>
                <tr>
                    <td colspan="3">Total</td>
                    <td>$<?php echo $total_price; ?></td>
                    <td></td>
                </tr>
            </table>
        
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </main>
</body>
</html>
