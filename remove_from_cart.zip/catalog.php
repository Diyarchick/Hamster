<?php
include('db.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalog</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Catalog</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="catalog.php">Catalog</a>
            <a href="cart.php">Cart</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="logout.php">Logout</a>
                <a href="account.php">Account</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                <a href="admin.php">Admin</a>
            <?php endif; ?>
        </nav>
    </header>
    <main>
        <form method="GET">
            <input type="text" name="search" placeholder="Search for games...">
            <button type="submit">Search</button>
        </form>
        <div class="games">
            <?php
            $search = isset($_GET['search']) ? $_GET['search'] : '';
            $sql = "SELECT * FROM games WHERE title LIKE '%$search%'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='game'>";
                    echo "<img src='" . $row['image'] . "' alt='" . $row['title'] . "'>";
                    echo "<h3>" . $row['title'] . "</h3>";
                    echo "<p>$" . $row['price'] . "</p>";
                    echo "<a href='product.php?id=" . $row['id'] . "'>View Details</a>";
                    echo "</div>";
                }
            } else {
                echo "No games found.";
            }
            ?>
        </div>
    </main>
</body>
</html>
