<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];
$sql = "DELETE FROM games WHERE id = $id";
if ($conn->query($sql) === TRUE) {
    header("Location: admin.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
