<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $game_id = $_POST['game_id'];
    $quantity = $_POST['quantity'];

    $sql = "INSERT INTO cart (user_id, game_id, quantity) VALUES ($user_id, $game_id, $quantity)";
    if ($conn->query($sql) === TRUE) {
        header("Location: cart.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
