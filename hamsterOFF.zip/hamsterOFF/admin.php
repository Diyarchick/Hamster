<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        $title = $conn->real_escape_string($_POST['title']);
        $description = $conn->real_escape_string($_POST['description']);
        $price = $conn->real_escape_string($_POST['price']);
        $image = $conn->real_escape_string($_POST['image']);
        
        $sql = "INSERT INTO games (title, description, price, image) VALUES ('$title', '$description', '$price', '$image')";
        if ($conn->query($sql) === TRUE) {
            echo "New game added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } elseif (isset($_POST['edit'])) {
        $id = $_POST['id'];
        $title = $conn->real_escape_string($_POST['title']);
        $description = $conn->real_escape_string($_POST['description']);
        $price = $conn->real_escape_string($_POST['price']);
        $image = $conn->real_escape_string($_POST['image']);
        
        $sql = "UPDATE games SET title='$title', description='$description', price='$price', image='$image' WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            echo "Game updated successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$sql = "SELECT * FROM games";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Admin Panel</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="catalog.php">Catalog</a>
            <a href="cart.php">Cart</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="logout.php">Logout</a>
                <a href="account.php">Account</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                <a href="admin.php">Admin</a>
            <?php endif; ?>
        </nav>
    </header>
    <main>
        <h2>Add New Game</h2>
        <form method="POST">
            <input type="hidden" name="add" value="1">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required>
            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea>
            <label for="price">Price:</label>
            <input type="number" step="0.01" id="price" name="price" required>
            <label for="image">Image URL:</label>
            <input type="text" id="image" name="image" required>
            <button type="submit">Add Game</button>
        </form>

        <h2>Manage Games</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Price</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td>$<?php echo $row['price']; ?></td>
                        <td><img src="<?php echo $row['image']; ?>" alt="<?php echo $row['title']; ?>" style="width:50px;"></td>
                        <td>
                            <form method="POST" style="display:inline-block;">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="edit" value="1">
                                <input type="text" name="title" value="<?php echo $row['title']; ?>" required>
                                <input type="text" name="description" value="<?php echo $row['description']; ?>" required>
                                <input type="number" step="0.01" name="price" value="<?php echo $row['price']; ?>" required>
                                <input type="text" name="image" value="<?php echo $row['image']; ?>" required>
                                <button type="submit">Edit</button>
                            </form>
                            <a href="remove_game.php?id=<?php echo $row['id']; ?>">Remove</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No games available.</td>
                </tr>
            <?php endif; ?>
        </table>
    </main>
</body>
</html>
