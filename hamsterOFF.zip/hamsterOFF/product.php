<?php
include('db.php');
session_start();

if (!isset($_GET['id'])) {
    header("Location: catalog.php");
    exit;
}

$id = $_GET['id'];
$sql = "SELECT * FROM games WHERE id = $id";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    header("Location: catalog.php");
    exit;
}
$game = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $rating = $_POST['rating'];
    $comment = $conn->real_escape_string($_POST['comment']);
    $sql = "INSERT INTO reviews (user_id, game_id, rating, comment) VALUES ($user_id, $id, $rating, '$comment')";
    if ($conn->query($sql) === TRUE) {
        // Update game rating
        $avg_rating_sql = "SELECT AVG(rating) AS avg_rating FROM reviews WHERE game_id = $id";
        $avg_rating_result = $conn->query($avg_rating_sql);
        $avg_rating_row = $avg_rating_result->fetch_assoc();
        $avg_rating = round($avg_rating_row['avg_rating'], 1);
        $update_rating_sql = "UPDATE games SET rating = $avg_rating WHERE id = $id";
        $conn->query($update_rating_sql);

        header("Location: product.php?id=$id");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$reviews_sql = "SELECT reviews.*, users.username FROM reviews JOIN users ON reviews.user_id = users.id WHERE game_id = $id";
$reviews_result = $conn->query($reviews_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $game['title']; ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1><?php echo $game['title']; ?></h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="catalog.php">Catalog</a>
            <a href="cart.php">Cart</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="logout.php">Logout</a>
                <a href="account.php">Account</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                <a href="admin.php">Admin</a>
            <?php endif; ?>
        </nav>
    </header>
    <main class="product">
        <img src="<?php echo $game['image']; ?>" alt="<?php echo $game['title']; ?>">
        <h2>Description</h2>
        <p><?php echo $game['description']; ?></p>
        <p>Price: $<?php echo $game['price']; ?></p>
        <p>Rating: <?php echo $game['rating']; ?></p>
        <form method="POST" action="add_to_cart.php">
            <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" value="1" min="1">
            <button type="submit">Add to Cart</button>
        </form>

        <h2>Reviews</h2>
        <?php if ($reviews_result->num_rows > 0): ?>
            <ul>
                <?php while($review = $reviews_result->fetch_assoc()): ?>
                    <li>
                        <strong><?php echo $review['username']; ?></strong> (Rating: <?php echo $review['rating']; ?>)
                        <p><?php echo $review['comment']; ?></p>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No reviews yet.</p>
        <?php endif; ?>

        <?php if (isset($_SESSION['user_id'])): ?>
            <h3>Leave a Review</h3>
            <form method="POST">
                <label for="rating">Rating:</label>
                <input type="number" id="rating" name="rating" min="1" max="5" required>
                <label for="comment">Comment:</label>
                <textarea id="comment" name="comment" required></textarea>
                <button type="submit">Submit Review</button>
            </form>
        <?php else: ?>
            <p><a href="login.php">Log in</a> to leave a review.</p>
        <?php endif; ?>
    </main>
</body>
</html>
